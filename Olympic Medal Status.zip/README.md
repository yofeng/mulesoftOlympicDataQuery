# olympic-data-analytics-demo
Using Olympics 2021 data to demonstrate analytical data loading and DataGraph in MuleSoft
